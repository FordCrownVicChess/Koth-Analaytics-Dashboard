async function fetchDataAndDisplay() {
    try {
        document.querySelector('.lobby__side').innerHTML="<h2>Loading....</h2>"
        const user_tag=document.querySelector('#user_tag')
        const victoryElement = '<div data-icon="" class="my-icon"></div>'
        const defeatElement = '<div data-icon="" class="my-icon"></div>'
        let count = 0
        const response = await fetch(`https://lichess.org/@/${user_tag?user_tag.textContent:'Ford_Crown_Vic'}/perf/kingOfTheHill`);
        if (!response.ok) {
            throw new Error('Failed to fetch data');
        }

        const htmlText = await response.text();
        const doc = new DOMParser().parseFromString(htmlText, 'text/html');

        // Getting victories data
        const victoriesArray = Array.from(doc.querySelectorAll('tr')[6]?.querySelectorAll('td') || []).map(td => td.textContent.trim());

        // Getting defeats data
        const defeatsArray = Array.from(doc.querySelectorAll('tr')[8]?.querySelectorAll('td') || []).map(td => td.textContent.trim());

        // Getting streaks data
        const longestStreak = doc.querySelector('.streak strong')?.textContent || ''
        const longestStreakDate = Array.from(doc.querySelector('.streak')?.querySelectorAll('time')|| []).map(item => item.textContent)
        const currentStreak = doc.querySelectorAll('.streak')[1].querySelector('strong')?.textContent || null
        console.log(currentStreak)
        const currenttStreakDate = Array.from(doc.querySelectorAll('.streak')[1]?.querySelectorAll('time') || []).map(item => item.textContent)

        // Getting highest rated wins data
        const highesRatedWinsArray = Array.from(doc.querySelectorAll('table')[2]?.querySelectorAll('td') || []).map(td => td.textContent.trim());

        // Combine all data arrays
        const allData = [...victoriesArray, ...defeatsArray, ...highesRatedWinsArray];
        console.log(allData)
        // Render to div.lobby__timeline
        const sideElement = `
        <h4>Victories/Defeats</h4>
    <section class="section">
        <div class="myWin">${victoryElement} ${victoriesArray[0]} <span>||</span> ${victoriesArray[1]}</div>
        <div class="myLosse">${defeatElement} ${defeatsArray[0]} <span>||</span> ${defeatsArray[1]}</div>
    </section>
    <h4>Streaks</h4>
    <section class="section">
        <div ><p class="underline-text">Longest</p>: <p class="myWin"><strong>${longestStreak}</strong> Games</p></div>
        <div>from <time>${longestStreakDate[0]}</time> to <time>${longestStreakDate[1]}</time></div>
        ${currentStreak ? `<div ><p class="underline-text">Current</p>: <p class="myWin"><strong>${currentStreak}</strong> Games</p></div><div>from <time>${currenttStreakDate[0]}</time> to <time>${currenttStreakDate[1]}</time></div>` : ''}

    </section>
    <h4>Best Rated</h4>
    <section class="section">
        ${highesRatedWinsArray.map(item => {
            ++count
            if (count % 2 === 0) {
                return `<time class="info">${item}</time>`
            }
            return `<div class="info">${item}</div>`
        }).join('')}
    </section>
        `;
        document.querySelector('div.lobby__side').innerHTML = sideElement;

    } catch (error) {
        console.error('Error fetching or parsing data:', error);
        // Handle error, maybe show a message on the page
        document.querySelector('.lobby__side').innerHTML="<h2>Something Went Wrong</h2>"
    }
}

// Call the function to fetch and display data
fetchDataAndDisplay();
